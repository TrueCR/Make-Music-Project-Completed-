function Music() {

    alert("It works"); // Remove this line if you got a popup when you clicked the button. This just verifys that your js is linked.
    
    
    //Break up text into individual sentences in the array "result"
   
    
    // Code in baby steps to ensure it's working
    

    
}



